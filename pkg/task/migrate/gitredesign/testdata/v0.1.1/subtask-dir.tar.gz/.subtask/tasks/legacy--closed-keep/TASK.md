---
title: Closed keep branch
base-branch: main
schema: 1
---

Closed task
