---
title: Closed delete branch
base-branch: main
schema: 1
---

Closed task
