---
title: Merged
base-branch: main
schema: 1
---

Merged task
